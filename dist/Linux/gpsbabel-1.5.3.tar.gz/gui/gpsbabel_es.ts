<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="es_ES">
<context>
    <name></name>
    <message>
        <location filename="foo.h" line="1"/>
        <source>Full path to XCSV style file</source>
        <translation>Ruta completa al fichero de estilo XCSV</translation>
    </message>
    <message>
        <location filename="foo.h" line="2"/>
        <location filename="foo.h" line="11"/>
        <location filename="foo.h" line="20"/>
        <location filename="foo.h" line="34"/>
        <location filename="foo.h" line="49"/>
        <location filename="foo.h" line="57"/>
        <location filename="foo.h" line="81"/>
        <location filename="foo.h" line="95"/>
        <location filename="foo.h" line="103"/>
        <location filename="foo.h" line="111"/>
        <location filename="foo.h" line="136"/>
        <location filename="foo.h" line="145"/>
        <location filename="foo.h" line="179"/>
        <location filename="foo.h" line="218"/>
        <location filename="foo.h" line="255"/>
        <location filename="foo.h" line="263"/>
        <location filename="foo.h" line="271"/>
        <location filename="foo.h" line="279"/>
        <location filename="foo.h" line="318"/>
        <location filename="foo.h" line="333"/>
        <location filename="foo.h" line="341"/>
        <location filename="foo.h" line="349"/>
        <location filename="foo.h" line="357"/>
        <location filename="foo.h" line="393"/>
        <location filename="foo.h" line="401"/>
        <location filename="foo.h" line="415"/>
        <location filename="foo.h" line="443"/>
        <location filename="foo.h" line="464"/>
        <location filename="foo.h" line="478"/>
        <location filename="foo.h" line="504"/>
        <location filename="foo.h" line="533"/>
        <location filename="foo.h" line="541"/>
        <location filename="foo.h" line="555"/>
        <location filename="foo.h" line="568"/>
        <location filename="foo.h" line="583"/>
        <location filename="foo.h" line="591"/>
        <source>Max synthesized shortname length</source>
        <translation>Longitud máxima del nombre corto</translation>
    </message>
    <message>
        <location filename="foo.h" line="3"/>
        <location filename="foo.h" line="12"/>
        <location filename="foo.h" line="21"/>
        <location filename="foo.h" line="35"/>
        <location filename="foo.h" line="50"/>
        <location filename="foo.h" line="58"/>
        <location filename="foo.h" line="82"/>
        <location filename="foo.h" line="96"/>
        <location filename="foo.h" line="104"/>
        <location filename="foo.h" line="112"/>
        <location filename="foo.h" line="137"/>
        <location filename="foo.h" line="146"/>
        <location filename="foo.h" line="161"/>
        <location filename="foo.h" line="180"/>
        <location filename="foo.h" line="201"/>
        <location filename="foo.h" line="219"/>
        <location filename="foo.h" line="256"/>
        <location filename="foo.h" line="264"/>
        <location filename="foo.h" line="272"/>
        <location filename="foo.h" line="280"/>
        <location filename="foo.h" line="319"/>
        <location filename="foo.h" line="334"/>
        <location filename="foo.h" line="342"/>
        <location filename="foo.h" line="350"/>
        <location filename="foo.h" line="358"/>
        <location filename="foo.h" line="394"/>
        <location filename="foo.h" line="402"/>
        <location filename="foo.h" line="416"/>
        <location filename="foo.h" line="444"/>
        <location filename="foo.h" line="465"/>
        <location filename="foo.h" line="479"/>
        <location filename="foo.h" line="505"/>
        <location filename="foo.h" line="534"/>
        <location filename="foo.h" line="542"/>
        <location filename="foo.h" line="556"/>
        <location filename="foo.h" line="569"/>
        <location filename="foo.h" line="584"/>
        <location filename="foo.h" line="592"/>
        <source>Allow whitespace synth. shortnames</source>
        <translation>Permitir espacios en nombres cortos</translation>
    </message>
    <message>
        <location filename="foo.h" line="4"/>
        <location filename="foo.h" line="13"/>
        <location filename="foo.h" line="22"/>
        <location filename="foo.h" line="36"/>
        <location filename="foo.h" line="51"/>
        <location filename="foo.h" line="59"/>
        <location filename="foo.h" line="83"/>
        <location filename="foo.h" line="97"/>
        <location filename="foo.h" line="105"/>
        <location filename="foo.h" line="113"/>
        <location filename="foo.h" line="138"/>
        <location filename="foo.h" line="147"/>
        <location filename="foo.h" line="181"/>
        <location filename="foo.h" line="220"/>
        <location filename="foo.h" line="257"/>
        <location filename="foo.h" line="265"/>
        <location filename="foo.h" line="273"/>
        <location filename="foo.h" line="281"/>
        <location filename="foo.h" line="320"/>
        <location filename="foo.h" line="335"/>
        <location filename="foo.h" line="343"/>
        <location filename="foo.h" line="351"/>
        <location filename="foo.h" line="359"/>
        <location filename="foo.h" line="395"/>
        <location filename="foo.h" line="403"/>
        <location filename="foo.h" line="417"/>
        <location filename="foo.h" line="445"/>
        <location filename="foo.h" line="466"/>
        <location filename="foo.h" line="480"/>
        <location filename="foo.h" line="506"/>
        <location filename="foo.h" line="535"/>
        <location filename="foo.h" line="543"/>
        <location filename="foo.h" line="557"/>
        <location filename="foo.h" line="570"/>
        <location filename="foo.h" line="585"/>
        <location filename="foo.h" line="593"/>
        <source>UPPERCASE synth. shortnames</source>
        <translation>MAYÚSCULAS en nombres cortos</translation>
    </message>
    <message>
        <location filename="foo.h" line="5"/>
        <location filename="foo.h" line="14"/>
        <location filename="foo.h" line="23"/>
        <location filename="foo.h" line="37"/>
        <location filename="foo.h" line="52"/>
        <location filename="foo.h" line="60"/>
        <location filename="foo.h" line="84"/>
        <location filename="foo.h" line="98"/>
        <location filename="foo.h" line="106"/>
        <location filename="foo.h" line="114"/>
        <location filename="foo.h" line="139"/>
        <location filename="foo.h" line="148"/>
        <location filename="foo.h" line="182"/>
        <location filename="foo.h" line="221"/>
        <location filename="foo.h" line="258"/>
        <location filename="foo.h" line="266"/>
        <location filename="foo.h" line="274"/>
        <location filename="foo.h" line="282"/>
        <location filename="foo.h" line="321"/>
        <location filename="foo.h" line="336"/>
        <location filename="foo.h" line="344"/>
        <location filename="foo.h" line="352"/>
        <location filename="foo.h" line="360"/>
        <location filename="foo.h" line="396"/>
        <location filename="foo.h" line="404"/>
        <location filename="foo.h" line="418"/>
        <location filename="foo.h" line="446"/>
        <location filename="foo.h" line="467"/>
        <location filename="foo.h" line="481"/>
        <location filename="foo.h" line="507"/>
        <location filename="foo.h" line="536"/>
        <location filename="foo.h" line="544"/>
        <location filename="foo.h" line="558"/>
        <location filename="foo.h" line="571"/>
        <location filename="foo.h" line="586"/>
        <location filename="foo.h" line="594"/>
        <source>Make synth. shortnames unique</source>
        <translation>Hacer los nombres cortos únicos</translation>
    </message>
    <message>
        <location filename="foo.h" line="6"/>
        <location filename="foo.h" line="15"/>
        <location filename="foo.h" line="24"/>
        <location filename="foo.h" line="38"/>
        <location filename="foo.h" line="53"/>
        <location filename="foo.h" line="61"/>
        <location filename="foo.h" line="85"/>
        <location filename="foo.h" line="99"/>
        <location filename="foo.h" line="107"/>
        <location filename="foo.h" line="115"/>
        <location filename="foo.h" line="140"/>
        <location filename="foo.h" line="149"/>
        <location filename="foo.h" line="183"/>
        <location filename="foo.h" line="222"/>
        <location filename="foo.h" line="259"/>
        <location filename="foo.h" line="267"/>
        <location filename="foo.h" line="275"/>
        <location filename="foo.h" line="283"/>
        <location filename="foo.h" line="322"/>
        <location filename="foo.h" line="337"/>
        <location filename="foo.h" line="345"/>
        <location filename="foo.h" line="353"/>
        <location filename="foo.h" line="361"/>
        <location filename="foo.h" line="397"/>
        <location filename="foo.h" line="405"/>
        <location filename="foo.h" line="419"/>
        <location filename="foo.h" line="447"/>
        <location filename="foo.h" line="468"/>
        <location filename="foo.h" line="482"/>
        <location filename="foo.h" line="537"/>
        <location filename="foo.h" line="545"/>
        <location filename="foo.h" line="559"/>
        <location filename="foo.h" line="572"/>
        <location filename="foo.h" line="587"/>
        <location filename="foo.h" line="595"/>
        <source>Basename prepended to URL on output</source>
        <translation>Prefijo añadido a la URL en la salida</translation>
    </message>
    <message>
        <location filename="foo.h" line="7"/>
        <location filename="foo.h" line="16"/>
        <location filename="foo.h" line="25"/>
        <location filename="foo.h" line="39"/>
        <location filename="foo.h" line="54"/>
        <location filename="foo.h" line="62"/>
        <location filename="foo.h" line="86"/>
        <location filename="foo.h" line="100"/>
        <location filename="foo.h" line="108"/>
        <location filename="foo.h" line="116"/>
        <location filename="foo.h" line="141"/>
        <location filename="foo.h" line="150"/>
        <location filename="foo.h" line="184"/>
        <location filename="foo.h" line="223"/>
        <location filename="foo.h" line="260"/>
        <location filename="foo.h" line="268"/>
        <location filename="foo.h" line="276"/>
        <location filename="foo.h" line="284"/>
        <location filename="foo.h" line="323"/>
        <location filename="foo.h" line="338"/>
        <location filename="foo.h" line="346"/>
        <location filename="foo.h" line="354"/>
        <location filename="foo.h" line="362"/>
        <location filename="foo.h" line="398"/>
        <location filename="foo.h" line="406"/>
        <location filename="foo.h" line="420"/>
        <location filename="foo.h" line="426"/>
        <location filename="foo.h" line="448"/>
        <location filename="foo.h" line="469"/>
        <location filename="foo.h" line="483"/>
        <location filename="foo.h" line="538"/>
        <location filename="foo.h" line="546"/>
        <location filename="foo.h" line="560"/>
        <location filename="foo.h" line="573"/>
        <location filename="foo.h" line="588"/>
        <location filename="foo.h" line="596"/>
        <source>Use shortname instead of description</source>
        <translation>Usar nombre corto en lugar de descripción</translation>
    </message>
    <message>
        <location filename="foo.h" line="8"/>
        <location filename="foo.h" line="17"/>
        <location filename="foo.h" line="26"/>
        <location filename="foo.h" line="40"/>
        <location filename="foo.h" line="55"/>
        <location filename="foo.h" line="63"/>
        <location filename="foo.h" line="87"/>
        <location filename="foo.h" line="101"/>
        <location filename="foo.h" line="109"/>
        <location filename="foo.h" line="117"/>
        <location filename="foo.h" line="142"/>
        <location filename="foo.h" line="151"/>
        <location filename="foo.h" line="168"/>
        <location filename="foo.h" line="185"/>
        <location filename="foo.h" line="224"/>
        <location filename="foo.h" line="261"/>
        <location filename="foo.h" line="269"/>
        <location filename="foo.h" line="277"/>
        <location filename="foo.h" line="285"/>
        <location filename="foo.h" line="324"/>
        <location filename="foo.h" line="339"/>
        <location filename="foo.h" line="347"/>
        <location filename="foo.h" line="355"/>
        <location filename="foo.h" line="363"/>
        <location filename="foo.h" line="399"/>
        <location filename="foo.h" line="407"/>
        <location filename="foo.h" line="421"/>
        <location filename="foo.h" line="449"/>
        <location filename="foo.h" line="470"/>
        <location filename="foo.h" line="484"/>
        <location filename="foo.h" line="539"/>
        <location filename="foo.h" line="547"/>
        <location filename="foo.h" line="561"/>
        <location filename="foo.h" line="574"/>
        <location filename="foo.h" line="589"/>
        <location filename="foo.h" line="597"/>
        <location filename="foo.h" line="616"/>
        <source>GPS datum (def. WGS 84)</source>
        <translation>GPS datum (def. WGS 84)</translation>
    </message>
    <message>
        <location filename="foo.h" line="9"/>
        <source>Alan Map500 tracklogs (.trl)</source>
        <translation>Registros de trazado Alan Map500 (.trl)</translation>
    </message>
    <message>
        <location filename="foo.h" line="10"/>
        <source>Alan Map500 waypoints and routes (.wpr)</source>
        <translation>Puntos de interés y rutas Alan Map500 (.wpr)</translation>
    </message>
    <message>
        <location filename="foo.h" line="18"/>
        <source>Brauniger IQ Series Barograph Download</source>
        <translation>Descarga de Brauniger IQ Series Barograph</translation>
    </message>
    <message>
        <location filename="foo.h" line="19"/>
        <source>Cambridge/Winpilot glider software</source>
        <translation>Cambridge/Winpilot glider software</translation>
    </message>
    <message>
        <location filename="foo.h" line="27"/>
        <source>CarteSurTable data file</source>
        <translation>Fichero CarteSurTable</translation>
    </message>
    <message>
        <location filename="foo.h" line="28"/>
        <source>Cetus for Palm/OS</source>
        <translation>Cetus para Palm/OS</translation>
    </message>
    <message>
        <location filename="foo.h" line="29"/>
        <location filename="foo.h" line="252"/>
        <location filename="foo.h" line="287"/>
        <location filename="foo.h" line="515"/>
        <location filename="foo.h" line="521"/>
        <location filename="foo.h" line="529"/>
        <source>Database name</source>
        <translation>Nombre de la base de datos</translation>
    </message>
    <message>
        <location filename="foo.h" line="30"/>
        <source>Append icon_descr to description</source>
        <translation>Añadir icon_descr a descripción</translation>
    </message>
    <message>
        <location filename="foo.h" line="31"/>
        <source>CoastalExplorer XML</source>
        <translation>CoastalExplorer XML</translation>
    </message>
    <message>
        <location filename="foo.h" line="32"/>
        <source>Columbus/Visiontac V900 files (.csv)</source>
        <translation>Ficheros Columbus/Visiontac V900 (.csv)</translation>
    </message>
    <message>
        <location filename="foo.h" line="33"/>
        <source>Comma separated values</source>
        <translation>Fichero separado por comas (CSV)</translation>
    </message>
    <message>
        <location filename="foo.h" line="41"/>
        <source>CompeGPS data files (.wpt/.trk/.rte)</source>
        <translation>Ficheros CompeGPS (.wpt/.trk/.rte)</translation>
    </message>
    <message>
        <location filename="foo.h" line="42"/>
        <location filename="foo.h" line="176"/>
        <location filename="foo.h" line="202"/>
        <location filename="foo.h" line="212"/>
        <location filename="foo.h" line="232"/>
        <location filename="foo.h" line="376"/>
        <location filename="foo.h" line="379"/>
        <location filename="foo.h" line="382"/>
        <location filename="foo.h" line="523"/>
        <source>Default icon name</source>
        <translation>Nombre de la imagen por defecto</translation>
    </message>
    <message>
        <location filename="foo.h" line="43"/>
        <location filename="foo.h" line="565"/>
        <source>Index of route/track to write (if more than one in source)</source>
        <translation>Indice de la ruta/trazado a escribir (si la fuente tiene más de uno)</translation>
    </message>
    <message>
        <location filename="foo.h" line="44"/>
        <source>Give points (waypoints/route points) a default radius (proximity)</source>
        <translation>Dar a los puntos (puntos de interes, puntos de ruta) un radio de proximidad por defecto</translation>
    </message>
    <message>
        <location filename="foo.h" line="45"/>
        <source>Length of generated shortnames (default 16)</source>
        <translation>Longitud de los nombres cortos generados (16 por defecto)</translation>
    </message>
    <message>
        <location filename="foo.h" line="46"/>
        <source>CoPilot Flight Planner for Palm/OS</source>
        <translation>CoPilot Flight Planner para Palm/OS</translation>
    </message>
    <message>
        <location filename="foo.h" line="47"/>
        <source>cotoGPS for Palm/OS</source>
        <translation>cotoGPS para Palm/OS</translation>
    </message>
    <message>
        <location filename="foo.h" line="48"/>
        <source>Name of the &apos;unassigned&apos; category</source>
        <translation>Nombre de la categoría &quot;no asignado&quot;</translation>
    </message>
    <message>
        <location filename="foo.h" line="56"/>
        <source>Data Logger iBlue747 csv</source>
        <translation>Data Logger iBlue747 csv</translation>
    </message>
    <message>
        <location filename="foo.h" line="64"/>
        <source>Dell Axim Navigation System (.gpb) file format</source>
        <translation>Ficheros Dell Axim Navigation System (.gpb)</translation>
    </message>
    <message>
        <location filename="foo.h" line="65"/>
        <source>DeLorme .an1 (drawing) file</source>
        <translation>Ficheros DeLorme .an1 (dibujo)</translation>
    </message>
    <message>
        <location filename="foo.h" line="66"/>
        <source>Type of .an1 file</source>
        <translation>Tipo de fichero .an1</translation>
    </message>
    <message>
        <location filename="foo.h" line="67"/>
        <source>Road type changes</source>
        <translation>Cambios en tipo de carretera</translation>
    </message>
    <message>
        <location filename="foo.h" line="68"/>
        <source>Do not add geocache data to description</source>
        <translation>No incluir datos del geochache en la descripción</translation>
    </message>
    <message>
        <location filename="foo.h" line="69"/>
        <source>Do not add URLs to description</source>
        <translation>No incluir URLs en la descripción</translation>
    </message>
    <message>
        <location filename="foo.h" line="70"/>
        <source>Symbol to use for point data</source>
        <translation>Símbolo para puntos</translation>
    </message>
    <message>
        <location filename="foo.h" line="71"/>
        <source>Color for lines or mapnotes</source>
        <translation>Color para las líneas o las notas de un mapa</translation>
    </message>
    <message>
        <location filename="foo.h" line="72"/>
        <source>Zoom level to reduce points</source>
        <translation>Nivel de zoom para reducir puntos</translation>
    </message>
    <message>
        <location filename="foo.h" line="73"/>
        <source>Waypoint type</source>
        <translation>Tipo de punto de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="74"/>
        <source>Radius for circles</source>
        <translation>Radio para círculos</translation>
    </message>
    <message>
        <location filename="foo.h" line="75"/>
        <source>DeLorme GPL</source>
        <translation>DeLorme GPL</translation>
    </message>
    <message>
        <location filename="foo.h" line="76"/>
        <source>DeLorme PN-20/PN-30/PN-40 USB protocol</source>
        <translation>Protocol USB DeLorme PN-20/PN-30/PN-40 </translation>
    </message>
    <message>
        <location filename="foo.h" line="78"/>
        <source>Include groundspeak logs when writing</source>
        <translation>Incluir registros &apos;groundspeak&apos; al escribir</translation>
    </message>
    <message>
        <location filename="foo.h" line="79"/>
        <source>Use long waypoint notes regardless of PN version</source>
        <translation>Usar notas largas en los puntos de interés independientemente de la versión PN</translation>
    </message>
    <message>
        <location filename="foo.h" line="80"/>
        <source>DeLorme Street Atlas Plus</source>
        <translation>DeLorme Street Atlas Plus</translation>
    </message>
    <message>
        <location filename="foo.h" line="88"/>
        <source>DeLorme Street Atlas Route</source>
        <translation>DeLorme Street Atlas Route</translation>
    </message>
    <message>
        <location filename="foo.h" line="89"/>
        <source>Keep turns if simplify filter is used</source>
        <translation>Preservar los giros si el filtro simplificar es usado</translation>
    </message>
    <message>
        <location filename="foo.h" line="90"/>
        <source>Only read turns; skip all other points</source>
        <translation>Leer sólo giros, saltar el resto de puntos</translation>
    </message>
    <message>
        <location filename="foo.h" line="91"/>
        <source>Split into multiple routes at turns</source>
        <translation></translation>
    </message>
    <message>
        <location filename="foo.h" line="92"/>
        <source>Read control points as waypoint/route/none</source>
        <translation>Leer los puntos de control como puntos de interés/ruta/ninguno</translation>
    </message>
    <message>
        <location filename="foo.h" line="93"/>
        <source>Synthesize track times</source>
        <translation>Calcular los tiempos del trazado</translation>
    </message>
    <message>
        <location filename="foo.h" line="94"/>
        <source>DeLorme XMap HH Native .WPT</source>
        <translation>DeLorme XMap HH Native .WPT</translation>
    </message>
    <message>
        <location filename="foo.h" line="102"/>
        <source>DeLorme XMap/SAHH 2006 Native .TXT</source>
        <translation>DeLorme XMap/SAHH 2006 Native .TXT</translation>
    </message>
    <message>
        <location filename="foo.h" line="110"/>
        <source>DeLorme XMat HH Street Atlas USA .WPT (PPC)</source>
        <translation>DeLorme XMat HH Street Atlas USA .WPT (PPC)</translation>
    </message>
    <message>
        <location filename="foo.h" line="118"/>
        <source>Destinator Itineraries (.dat)</source>
        <translation>Itinerarios Destinator (.dat)</translation>
    </message>
    <message>
        <location filename="foo.h" line="119"/>
        <source>Destinator Points of Interest (.dat)</source>
        <translation>Puntos de interés Destinator (.dat)</translation>
    </message>
    <message>
        <location filename="foo.h" line="120"/>
        <source>Destinator TrackLogs (.dat)</source>
        <translation>Trazadis Destinator (.dat)</translation>
    </message>
    <message>
        <location filename="foo.h" line="121"/>
        <source>EasyGPS binary format</source>
        <translation>Formato binario EasyGPS</translation>
    </message>
    <message>
        <location filename="foo.h" line="122"/>
        <source>Embedded Exif-GPS data (.jpg)</source>
        <translation>Metadatos Exif-GPS (.jpg)</translation>
    </message>
    <message>
        <location filename="foo.h" line="123"/>
        <source>Set waypoint name to source filename</source>
        <translatorcomment>No estoy seguro</translatorcomment>
        <translation>Poner el nombre del punto de interés al fichero fuente</translation>
    </message>
    <message>
        <location filename="foo.h" line="124"/>
        <source>Time-frame (in seconds)</source>
        <translation>Secuencia (en segundos)</translation>
    </message>
    <message>
        <location filename="foo.h" line="125"/>
        <source>Locate waypoint for tagging by this name</source>
        <translation>Localizar el punto de interés para etiquetar con este nombre</translation>
    </message>
    <message>
        <location filename="foo.h" line="126"/>
        <source>!OVERWRITE! the original file. Default=N</source>
        <translation>¡Seguro! que quieres sobreescribir el fichero original. Por defecto=N</translation>
    </message>
    <message>
        <location filename="foo.h" line="127"/>
        <source>Enigma binary waypoint file (.ert)</source>
        <translation>Fichero binario de puntos de interés (.ert)</translation>
    </message>
    <message>
        <location filename="foo.h" line="128"/>
        <source>Index of name field in .dbf</source>
        <translation>Indice del campo nombre en .dbf</translation>
    </message>
    <message>
        <location filename="foo.h" line="129"/>
        <source>Index of URL field in .dbf</source>
        <translation>Indice del campo URL en .dbf</translation>
    </message>
    <message>
        <location filename="foo.h" line="130"/>
        <source>FAI/IGC Flight Recorder Data Format</source>
        <translation>Formato de datos FAI/IGC Flight Recorder</translation>
    </message>
    <message>
        <location filename="foo.h" line="131"/>
        <source>(integer sec or &apos;auto&apos;) Barograph to GPS time diff</source>
        <translation>(entero seg o &apos;auto&apos;) Barograph a GPS tiempo diff</translation>
    </message>
    <message>
        <location filename="foo.h" line="132"/>
        <source>Franson GPSGate Simulation</source>
        <translation>Simulación Franson GPSGate</translation>
    </message>
    <message>
        <location filename="foo.h" line="133"/>
        <source>Default speed for waypoints (knots/hr)</source>
        <translation>Velocidad por defecto para puntos de interés (nudos)</translation>
    </message>
    <message>
        <location filename="foo.h" line="134"/>
        <source>Split input into separate files</source>
        <translation>Dividir en ficheros separados</translation>
    </message>
    <message>
        <location filename="foo.h" line="135"/>
        <source>Fugawi</source>
        <translation>Fugawi</translation>
    </message>
    <message>
        <location filename="foo.h" line="143"/>
        <source>G7ToWin data files (.g7t)</source>
        <translation>Ficheros de datos G7ToWin</translation>
    </message>
    <message>
        <location filename="foo.h" line="144"/>
        <source>Garmin 301 Custom position and heartrate</source>
        <translation>Localización y frecuencia de latido Garmin 301 personalizado</translation>
    </message>
    <message>
        <location filename="foo.h" line="152"/>
        <source>Garmin Logbook XML</source>
        <translation>Garmin Logbook XML</translation>
    </message>
    <message>
        <location filename="foo.h" line="153"/>
        <source>Garmin MapSource - gdb</source>
        <translation>Garmin MapSource - gdb</translation>
    </message>
    <message>
        <location filename="foo.h" line="154"/>
        <source>Default category on output (1..16)</source>
        <translation>Categoría por defecto en la salida (1..16)</translation>
    </message>
    <message>
        <location filename="foo.h" line="155"/>
        <location filename="foo.h" line="207"/>
        <source>Bitmap of categories</source>
        <translation>Bitmap de categorías</translation>
    </message>
    <message>
        <location filename="foo.h" line="156"/>
        <source>Version of gdb file to generate (1..3)</source>
        <translation>Versión del fichero gdb a generar (1..3)</translation>
    </message>
    <message>
        <location filename="foo.h" line="157"/>
        <source>Drop route points that do not have an equivalent waypoint (hidden points)</source>
        <translation>Eliminar puntos de ruta que no tienen un punto de interés equivalente (puntos ocultos)</translation>
    </message>
    <message>
        <location filename="foo.h" line="158"/>
        <source>Include major turn points (with description) from calculated route</source>
        <translation>Incluir giros importantes (con descripción) de la ruta calculada</translation>
    </message>
    <message>
        <location filename="foo.h" line="159"/>
        <source>Garmin MapSource - mps</source>
        <translation>Garmin MapSource - mps</translation>
    </message>
    <message>
        <location filename="foo.h" line="160"/>
        <location filename="foo.h" line="200"/>
        <location filename="foo.h" line="290"/>
        <location filename="foo.h" line="524"/>
        <source>Length of generated shortnames</source>
        <translation>Longitud de los nombres cortos generados</translation>
    </message>
    <message>
        <location filename="foo.h" line="162"/>
        <source>Version of mapsource file to generate (3,4,5)</source>
        <translation>Versión del fichero mapsource a generar (3,4,5)</translation>
    </message>
    <message>
        <location filename="foo.h" line="163"/>
        <source>Merge output with existing file</source>
        <translation>Unir el resultado con el fichero existente</translation>
    </message>
    <message>
        <location filename="foo.h" line="164"/>
        <source>Use depth values on output (default is ignore)</source>
        <translation>Usar valores de profundidad en el resultado (por defecto se ignoran)</translation>
    </message>
    <message>
        <location filename="foo.h" line="165"/>
        <source>Use proximity values on output (default is ignore)</source>
        <translation>Usar valores de proximidad en el resultado (por defecto se ignoran)</translation>
    </message>
    <message>
        <location filename="foo.h" line="166"/>
        <source>Garmin MapSource - txt (tab delimited)</source>
        <translation>Garmin MapSource - txt (delimitado por tabuladores)</translation>
    </message>
    <message>
        <location filename="foo.h" line="167"/>
        <source>Read/Write date format (i.e. yyyy/mm/dd)</source>
        <translation>Leer/Escribir el formato de la fecha (por ejemplo aaaa/mm/dd)</translation>
    </message>
    <message>
        <location filename="foo.h" line="169"/>
        <source>Distance unit [m=metric, s=statute]</source>
        <translation>Unidades de distancia  [m=métricas, s=statute]</translation>
    </message>
    <message>
        <location filename="foo.h" line="170"/>
        <location filename="foo.h" line="617"/>
        <source>Write position using this grid.</source>
        <translation>Escribir la posición usando esta cuadrícula.</translation>
    </message>
    <message>
        <location filename="foo.h" line="171"/>
        <source>Precision of coordinates</source>
        <translation>Precisión de las coordenadas</translation>
    </message>
    <message>
        <location filename="foo.h" line="172"/>
        <source>Temperature unit [c=Celsius, f=Fahrenheit]</source>
        <translation>Unidad de temperatura [c=Celsius, f=Fahrenheit]</translation>
    </message>
    <message>
        <location filename="foo.h" line="173"/>
        <source>Read/Write time format (i.e. HH:mm:ss xx)</source>
        <translation>Leer/Escribir el formato de la hora (por ejemplo  HH:mm:ss xx)</translation>
    </message>
    <message>
        <location filename="foo.h" line="174"/>
        <location filename="foo.h" line="618"/>
        <source>Write timestamps with offset x to UTC time</source>
        <translation>Escribir marcas de tiempo con un retraso de x a UTC</translation>
    </message>
    <message>
        <location filename="foo.h" line="175"/>
        <source>Garmin PCX5</source>
        <translation>Garmin PCX5</translation>
    </message>
    <message>
        <location filename="foo.h" line="177"/>
        <source>Write tracks compatible with Carto Exploreur</source>
        <translation>Escribir trazados compatibles con Carto Exploreur</translation>
    </message>
    <message>
        <location filename="foo.h" line="178"/>
        <source>Garmin POI database</source>
        <translation>Base de datos Garmin POI (Puntos de Interés)</translation>
    </message>
    <message>
        <location filename="foo.h" line="186"/>
        <source>Garmin Points of Interest (.gpi)</source>
        <translation>Puntos de interés Garmin (.gpi)</translation>
    </message>
    <message>
        <location filename="foo.h" line="187"/>
        <source>Enable alerts on speed or proximity distance</source>
        <translation>Habilitar alertas sobre la velocidad o la proximidad</translation>
    </message>
    <message>
        <location filename="foo.h" line="188"/>
        <source>Use specified bitmap on output</source>
        <translation>Usar bitmap especificado en el resultado</translation>
    </message>
    <message>
        <location filename="foo.h" line="189"/>
        <source>Default category on output</source>
        <translation>Categoría por defecto en la salida</translation>
    </message>
    <message>
        <location filename="foo.h" line="190"/>
        <source>Don&apos;t show gpi bitmap on device</source>
        <translation>No mostrar gpi bitmap en el dispositivo</translation>
    </message>
    <message>
        <location filename="foo.h" line="191"/>
        <source>Write description to address field</source>
        <translation>Escribir la descripción al campo dirección</translation>
    </message>
    <message>
        <location filename="foo.h" line="192"/>
        <source>Write notes to address field</source>
        <translation>Escribir las notas al campo dirección</translation>
    </message>
    <message>
        <location filename="foo.h" line="193"/>
        <source>Write position to address field</source>
        <translation>Escribir la posición al campo dirección</translation>
    </message>
    <message>
        <location filename="foo.h" line="194"/>
        <source>Default proximity</source>
        <translation>Proximidad por defecto</translation>
    </message>
    <message>
        <location filename="foo.h" line="195"/>
        <source>After output job done sleep n second(s)</source>
        <translation>Después de recibir la señal de trabajo realizado, dormir n segundo(s)</translation>
    </message>
    <message>
        <location filename="foo.h" line="196"/>
        <source>Default speed</source>
        <translation>Velocidad por defecto</translation>
    </message>
    <message>
        <location filename="foo.h" line="197"/>
        <source>Create unique waypoint names (default = yes)</source>
        <translation>Crear nombres únicos para los puntos de interés (defecto=si)</translation>
    </message>
    <message>
        <location filename="foo.h" line="198"/>
        <source>Units used for names with @speed (&apos;s&apos;tatute or &apos;m&apos;etric)</source>
        <translation>Unidades usadas para nombres con @velocidad (&apos;s&apos;tatute p &apos;m&apos;etricas)</translation>
    </message>
    <message>
        <location filename="foo.h" line="199"/>
        <source>Garmin serial/USB protocol</source>
        <translation>Protocolo serial/USB Garmin</translation>
    </message>
    <message>
        <location filename="foo.h" line="77"/>
        <location filename="foo.h" line="203"/>
        <location filename="foo.h" line="492"/>
        <source>Return current position as a waypoint</source>
        <translation>Devolver la posición actual como un punto de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="204"/>
        <location filename="foo.h" line="456"/>
        <source>Command unit to power itself down</source>
        <translation>Mandar apagarse a la unidad de GPS</translation>
    </message>
    <message>
        <location filename="foo.h" line="205"/>
        <source>Sync GPS time to computer time</source>
        <translation>Sincronizar la hora con el ordenador</translation>
    </message>
    <message>
        <location filename="foo.h" line="206"/>
        <source>Category number to use for written waypoints</source>
        <translation>Número de la categoría donde escribir los puntos de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="208"/>
        <source>Garmin Training Center</source>
        <translation>Centro de Entrenamiento Garmin</translation>
    </message>
    <message>
        <location filename="foo.h" line="209"/>
        <source>Write course rather than history, default yes</source>
        <translation>Escribir la dirección en lugar de la historia, por defecto si</translation>
    </message>
    <message>
        <location filename="foo.h" line="210"/>
        <source>Sport: Biking (deflt), Running, MultiSport, Other</source>
        <translation>Deporte: Ciclismo(deflt), Correr, MultiDeporte, Otros</translation>
    </message>
    <message>
        <location filename="foo.h" line="211"/>
        <source>Geocaching.com .loc</source>
        <translation>Geocaching.com .loc</translation>
    </message>
    <message>
        <location filename="foo.h" line="213"/>
        <source>Omit Placer name</source>
        <translation>Omitir el nombre del lugar</translation>
    </message>
    <message>
        <location filename="foo.h" line="214"/>
        <source>GeocachingDB for Palm/OS</source>
        <translation>GeocachingDB para Palm/OS</translation>
    </message>
    <message>
        <location filename="foo.h" line="215"/>
        <source>Geogrid-Viewer ascii overlay file (.ovl)</source>
        <translation>Fichero de Transparencia ascii Geogrid-Viewer (.ovl)</translation>
    </message>
    <message>
        <location filename="foo.h" line="216"/>
        <source>Geogrid-Viewer tracklogs (.log)</source>
        <translation>Trazados Geogrid-Viewer (.log)</translation>
    </message>
    <message>
        <location filename="foo.h" line="217"/>
        <source>GEOnet Names Server (GNS)</source>
        <translation>Servidor de Topónimos GEOnet (GNS)</translation>
    </message>
    <message>
        <location filename="foo.h" line="225"/>
        <source>GeoNiche .pdb</source>
        <translation>GeoNiche .pdb</translation>
    </message>
    <message>
        <location filename="foo.h" line="226"/>
        <source>Database name (filename)</source>
        <translation>Nombre de la base de datos (nombre del fichero)</translation>
    </message>
    <message>
        <location filename="foo.h" line="227"/>
        <source>Category name (Cache)</source>
        <translation>Nombre de la categoría (Caché)</translation>
    </message>
    <message>
        <location filename="foo.h" line="228"/>
        <source>GlobalSat DG-100/BT-335 Download</source>
        <translation>Bajar GlobalSat DG-100/BT-335</translation>
    </message>
    <message>
        <location filename="foo.h" line="229"/>
        <location filename="foo.h" line="302"/>
        <location filename="foo.h" line="431"/>
        <location filename="foo.h" line="550"/>
        <location filename="foo.h" line="635"/>
        <source>Erase device data after download</source>
        <translation>Borrar dispostivio después de la descarga</translation>
    </message>
    <message>
        <location filename="foo.h" line="230"/>
        <source>Only erase device data, do not download anything</source>
        <translation>Sólo borrar los datos del dispositivo, no descargar nada</translation>
    </message>
    <message>
        <location filename="foo.h" line="231"/>
        <source>Google Earth (Keyhole) Markup Language</source>
        <translation>Google Earth (Keyhole) Markup Language KML</translation>
    </message>
    <message>
        <location filename="foo.h" line="233"/>
        <source>Export linestrings for tracks and routes</source>
        <translation>Exportar cadenas de texto de los trazados y rutas</translation>
    </message>
    <message>
        <location filename="foo.h" line="234"/>
        <source>Export placemarks for tracks and routes</source>
        <translation>Exportar hitos de los trazados y rutas</translation>
    </message>
    <message>
        <location filename="foo.h" line="235"/>
        <source>Width of lines, in pixels</source>
        <translation>Achura de las líneas (en píxeles)</translation>
    </message>
    <message>
        <location filename="foo.h" line="236"/>
        <source>Line color, specified in hex AABBGGRR</source>
        <translation>Color de la línea, en hex AABBGGRR</translation>
    </message>
    <message>
        <location filename="foo.h" line="237"/>
        <source>Altitudes are absolute and not clamped to ground</source>
        <translation>Las altitudes son absolutas y no están pegadas al terreno</translation>
    </message>
    <message>
        <location filename="foo.h" line="238"/>
        <source>Draw extrusion line from trackpoint to ground</source>
        <translation>Extruir línea desde el trazado hasta el suelo</translation>
    </message>
    <message>
        <location filename="foo.h" line="239"/>
        <source>Include extended data for trackpoints (default = 1)</source>
        <translation>Incluir datos extendidos para los puntos de trazado (defecto=1)</translation>
    </message>
    <message>
        <location filename="foo.h" line="240"/>
        <source>Indicate direction of travel in track icons (default = 0)</source>
        <translation>Indicar la dirección del viaje con iconos (defecto=0)</translation>
    </message>
    <message>
        <location filename="foo.h" line="241"/>
        <source>Units used when writing comments (&apos;s&apos;tatute or &apos;m&apos;etric)</source>
        <translation>Unidades usadas al escribir los comentarios (&apos;s&apos;tatute p &apos;m&apos;etricas)</translation>
    </message>
    <message>
        <location filename="foo.h" line="242"/>
        <source>Display labels on track and routepoints  (default = 1)</source>
        <translation>Mostrar etiquetas en los puntos de los trazados y las rutas (defecto= 1)</translation>
    </message>
    <message>
        <location filename="foo.h" line="243"/>
        <source>Retain at most this number of position points  (0 = unlimited)</source>
        <translation>Retener como máximo este número de puntos de posición (0 = ilimitados)</translation>
    </message>
    <message>
        <location filename="foo.h" line="244"/>
        <source>Google Maps XML</source>
        <translation>Google Maps XML</translation>
    </message>
    <message>
        <location filename="foo.h" line="245"/>
        <source>Google Navigator Tracklines (.trl)</source>
        <translation>Google Navigator Tracklines (.trl)</translation>
    </message>
    <message>
        <location filename="foo.h" line="246"/>
        <source>GoPal GPS track log (.trk)</source>
        <translation>Trazado GoPal GPS (.trk)</translation>
    </message>
    <message>
        <location filename="foo.h" line="247"/>
        <location filename="foo.h" line="491"/>
        <source>Complete date-free tracks with given date (YYYYMMDD).</source>
        <translation>Completar trazados con una fecha determinada (AAAAMMDD).</translation>
    </message>
    <message>
        <location filename="foo.h" line="248"/>
        <source>The maximum speed (km/h) traveling from waypoint to waypoint.</source>
        <translation>La velocidad máxima (Km/h) desde un punto a otro.</translation>
    </message>
    <message>
        <location filename="foo.h" line="249"/>
        <source>The minimum speed (km/h) traveling from waypoint to waypoint. Set &gt;0 to remove duplicate waypoints</source>
        <translation>La velocidad mínima (Km/h) desde un punto a otro. Poner a &gt;0 para eliminar duplicados</translation>
    </message>
    <message>
        <location filename="foo.h" line="250"/>
        <source>Cleanup common errors in trackdata</source>
        <translation>Limpiar errores comunes en trazados</translation>
    </message>
    <message>
        <location filename="foo.h" line="251"/>
        <source>GpilotS</source>
        <translation>GpilotS</translation>
    </message>
    <message>
        <location filename="foo.h" line="253"/>
        <source>GPS TrackMaker</source>
        <translation>GPS TrackMaker</translation>
    </message>
    <message>
        <location filename="foo.h" line="254"/>
        <source>GPSBabel arc filter file</source>
        <translation>Fichero de filtro arc GPSBabel</translation>
    </message>
    <message>
        <location filename="foo.h" line="262"/>
        <source>GpsDrive Format</source>
        <translation>Formato GpsDrive</translation>
    </message>
    <message>
        <location filename="foo.h" line="270"/>
        <source>GpsDrive Format for Tracks</source>
        <translation>Formato GpsDrive para trazados</translation>
    </message>
    <message>
        <location filename="foo.h" line="278"/>
        <source>GPSman</source>
        <translation>GPSman</translation>
    </message>
    <message>
        <location filename="foo.h" line="286"/>
        <source>GPSPilot Tracker for Palm/OS</source>
        <translation>GPSPilot Tracker para Palm/OS</translation>
    </message>
    <message>
        <location filename="foo.h" line="288"/>
        <source>gpsutil</source>
        <translation>gpsutil</translation>
    </message>
    <message>
        <location filename="foo.h" line="289"/>
        <source>GPX XML</source>
        <translation>GPX XML</translation>
    </message>
    <message>
        <location filename="foo.h" line="291"/>
        <source>No whitespace in generated shortnames</source>
        <translation>No permitir espacios en nombres cortos generados</translation>
    </message>
    <message>
        <location filename="foo.h" line="292"/>
        <source>Create waypoints from geocache log entries</source>
        <translation>Crear puntos de interés desde las entradas de los trazados geocache</translation>
    </message>
    <message>
        <location filename="foo.h" line="293"/>
        <source>Base URL for link tag in output</source>
        <translation>URL base para enlazar etiquetas en el resultado</translation>
    </message>
    <message>
        <location filename="foo.h" line="294"/>
        <source>Target GPX version for output</source>
        <translation>Versión GPX del resultado</translation>
    </message>
    <message>
        <location filename="foo.h" line="295"/>
        <source>Add info (depth) as Humminbird extension</source>
        <translation>Añadir info (profundidad) como extensión Humminbird</translation>
    </message>
    <message>
        <location filename="foo.h" line="296"/>
        <source>Add info (depth) as Garmin extension</source>
        <translation>Añadir info (profundidad) como extensión Garmin</translation>
    </message>
    <message>
        <location filename="foo.h" line="297"/>
        <source>HikeTech</source>
        <translation>HikeTech</translation>
    </message>
    <message>
        <location filename="foo.h" line="298"/>
        <source>Holux (gm-100) .wpo Format</source>
        <translation>Formato Holux (gm-100) .wpo </translation>
    </message>
    <message>
        <location filename="foo.h" line="299"/>
        <source>Holux M-241 (MTK based) Binary File Format</source>
        <translation>Formato de fichero binario Holux M-241 (MTK based)</translation>
    </message>
    <message>
        <location filename="foo.h" line="300"/>
        <location filename="foo.h" line="304"/>
        <location filename="foo.h" line="429"/>
        <location filename="foo.h" line="433"/>
        <source>MTK compatible CSV output file</source>
        <translation>Fichero de salida CSV MTK compatible</translation>
    </message>
    <message>
        <location filename="foo.h" line="301"/>
        <source>Holux M-241 (MTK based) download</source>
        <translation>Descarga de Holux M-241 (basado en MTK)</translation>
    </message>
    <message>
        <location filename="foo.h" line="303"/>
        <location filename="foo.h" line="432"/>
        <source>Enable logging after download</source>
        <translation>Habilitar registro después de la descarga</translation>
    </message>
    <message>
        <location filename="foo.h" line="305"/>
        <source>Honda/Acura Navigation System VP Log File Format</source>
        <translation>Fichero de trazado formato Honda/Acura Navigation System VP</translation>
    </message>
    <message>
        <location filename="foo.h" line="306"/>
        <source>HSA Endeavour Navigator export File</source>
        <translation>Fihero de exportación HSA Endeavour Navigator</translation>
    </message>
    <message>
        <location filename="foo.h" line="307"/>
        <source>HTML Output</source>
        <translation>Salida a HTML</translation>
    </message>
    <message>
        <location filename="foo.h" line="308"/>
        <source>Path to HTML style sheet</source>
        <translation>Ruta a la hoja de estilo HTML</translation>
    </message>
    <message>
        <location filename="foo.h" line="309"/>
        <location filename="foo.h" line="577"/>
        <location filename="foo.h" line="622"/>
        <source>Encrypt hints using ROT13</source>
        <translation>Emcriptar trucos usando ROT13</translation>
    </message>
    <message>
        <location filename="foo.h" line="310"/>
        <location filename="foo.h" line="517"/>
        <location filename="foo.h" line="578"/>
        <source>Include groundspeak logs if present</source>
        <translation>Incluir registros &apos;groundspeak&apos; si están presentes</translation>
    </message>
    <message>
        <location filename="foo.h" line="311"/>
        <location filename="foo.h" line="579"/>
        <source>Degrees output as &apos;ddd&apos;, &apos;dmm&apos;(default) or &apos;dms&apos;</source>
        <translation>Salida en grados como &apos;ddd&apos;, &apos;dmm&apos;(defecto) o &apos;dms&apos;</translation>
    </message>
    <message>
        <location filename="foo.h" line="312"/>
        <location filename="foo.h" line="580"/>
        <source>Units for altitude (f)eet or (m)etres</source>
        <translation>Unidades de altitud pies (f) o metros (m)</translation>
    </message>
    <message>
        <location filename="foo.h" line="313"/>
        <source>Humminbird tracks (.ht)</source>
        <translation>Trazados Humminbird (.ht)</translation>
    </message>
    <message>
        <location filename="foo.h" line="314"/>
        <source>Humminbird waypoints and routes (.hwr)</source>
        <translation>Puntos de interés y rutas Humminbird (.hwr)</translation>
    </message>
    <message>
        <location filename="foo.h" line="315"/>
        <source>IGN Rando track files</source>
        <translation>Trazados IGN Rando </translation>
    </message>
    <message>
        <location filename="foo.h" line="316"/>
        <source>Index of track to write (if more than one in source)</source>
        <translation>Indice del trazado a escribir (si la fuente tiene más de uno)</translation>
    </message>
    <message>
        <location filename="foo.h" line="317"/>
        <source>iGO2008 points of interest (.upoi)</source>
        <translation>Puntos de interés iGO2008 (.upoi)</translation>
    </message>
    <message>
        <location filename="foo.h" line="325"/>
        <source>IGO8 .trk</source>
        <translation>IGO8 .trk</translation>
    </message>
    <message>
        <location filename="foo.h" line="326"/>
        <source>Track identification number</source>
        <translation>Identificador del tratado</translation>
    </message>
    <message>
        <location filename="foo.h" line="327"/>
        <source>Track title</source>
        <translation>Título del trazado</translation>
    </message>
    <message>
        <location filename="foo.h" line="328"/>
        <source>Track description</source>
        <translation>Descripción del trazado</translation>
    </message>
    <message>
        <location filename="foo.h" line="329"/>
        <source>Generate # points</source>
        <translation>Generar n points</translation>
    </message>
    <message>
        <location filename="foo.h" line="330"/>
        <source>Starting seed of the internal number generator</source>
        <translation>Iniciar el generador interno de números</translation>
    </message>
    <message>
        <location filename="foo.h" line="331"/>
        <source>Jelbert GeoTagger data file</source>
        <translation>Fichero de datos Jelbert GeoTagger</translation>
    </message>
    <message>
        <location filename="foo.h" line="332"/>
        <source>Kartex 5 Track File</source>
        <translation>Trazado Kartex 5</translation>
    </message>
    <message>
        <location filename="foo.h" line="340"/>
        <source>Kartex 5 Waypoint File</source>
        <translation>Fichero de puntos de interés Kartex 5</translation>
    </message>
    <message>
        <location filename="foo.h" line="348"/>
        <source>Kompass (DAV) Track (.tk)</source>
        <translation>Trazado Kompass (DAV) (.tk)</translation>
    </message>
    <message>
        <location filename="foo.h" line="356"/>
        <source>Kompass (DAV) Waypoints (.wp)</source>
        <translation>Puntos de interés Kompass (DAV) (.wp)</translation>
    </message>
    <message>
        <location filename="foo.h" line="364"/>
        <source>KuDaTa PsiTrex text</source>
        <translation>Texto KuDaTa PsiTrex</translation>
    </message>
    <message>
        <location filename="foo.h" line="365"/>
        <source>Lowrance USR</source>
        <translation>Lowrance USR</translation>
    </message>
    <message>
        <location filename="foo.h" line="366"/>
        <source>Ignore event marker icons on read</source>
        <translation>Ignorar iconos al leer</translation>
    </message>
    <message>
        <location filename="foo.h" line="367"/>
        <source>Treat waypoints as icons on write</source>
        <translation>Tratar puntos de interés como iconos al escribir</translation>
    </message>
    <message>
        <location filename="foo.h" line="368"/>
        <source>(USR output) Merge into one segmented track</source>
        <translation>(salida USR) Unir en un trazado segmentado</translation>
    </message>
    <message>
        <location filename="foo.h" line="369"/>
        <source>(USR input) Break segments into separate tracks</source>
        <translation>(entrada USR) Dividir los segmentos en trazados separados</translation>
    </message>
    <message>
        <location filename="foo.h" line="370"/>
        <source>(USR output) Write version</source>
        <translation>(salida USR) Escribir versión</translation>
    </message>
    <message>
        <location filename="foo.h" line="371"/>
        <source>Magellan Explorist Geocaching</source>
        <translation>Magellan Explorist Geocaching</translation>
    </message>
    <message>
        <location filename="foo.h" line="372"/>
        <source>Magellan Mapsend</source>
        <translation>Magellan Mapsend</translation>
    </message>
    <message>
        <location filename="foo.h" line="373"/>
        <source>MapSend version TRK file to generate (3,4)</source>
        <translation>versión del fichero TRK MapSend a generar (3,4)</translation>
    </message>
    <message>
        <location filename="foo.h" line="374"/>
        <source>Magellan NAV Companion for Palm/OS</source>
        <translation>Magellan NAV Companion para Palm/OS</translation>
    </message>
    <message>
        <location filename="foo.h" line="375"/>
        <source>Magellan SD files (as for eXplorist)</source>
        <translation>Ficheros Magellan SD (como los del eXplorist)</translation>
    </message>
    <message>
        <location filename="foo.h" line="377"/>
        <location filename="foo.h" line="380"/>
        <location filename="foo.h" line="383"/>
        <source>Max number of comments to write (maxcmts=200)</source>
        <translation>Máximo número de comentarios a escribir (maxcmts=200)</translation>
    </message>
    <message>
        <location filename="foo.h" line="378"/>
        <source>Magellan SD files (as for Meridian)</source>
        <translation>Ficheros Magellan SD (como los del Meridian)</translation>
    </message>
    <message>
        <location filename="foo.h" line="381"/>
        <source>Magellan serial protocol</source>
        <translation>Protocolo serie Magellan</translation>
    </message>
    <message>
        <location filename="foo.h" line="384"/>
        <source>Numeric value of bitrate (baud=4800)</source>
        <translation>Valor numérico de la conexión (baudios=4800)</translation>
    </message>
    <message>
        <location filename="foo.h" line="385"/>
        <source>Suppress use of handshaking in name of speed</source>
        <translatorcomment>no sé</translatorcomment>
        <translation>Suprimir el uso del agitador en nombre de la velocidad</translation>
    </message>
    <message>
        <location filename="foo.h" line="386"/>
        <location filename="foo.h" line="453"/>
        <source>Delete all waypoints</source>
        <translation>Borrrar todos los puntos de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="387"/>
        <source>MagicMaps IK3D project file (.ikt)</source>
        <translation>Fichero de proyecto MagicMaps IK3D (.ikt)</translation>
    </message>
    <message>
        <location filename="foo.h" line="388"/>
        <source>Map&amp;Guide &apos;TourExchangeFormat&apos; XML</source>
        <translation>Map&amp;Guide &apos;TourExchangeFormat&apos; XML</translation>
    </message>
    <message>
        <location filename="foo.h" line="389"/>
        <source>Include only via stations in route</source>
        <translation>Incluir sólo a través de las estaciones en la ruta</translation>
    </message>
    <message>
        <location filename="foo.h" line="390"/>
        <source>Map&amp;Guide to Palm/OS exported files (.pdb)</source>
        <translation>Fichero de exportación Map&amp;Guide a Palm/OS (.pdb)</translation>
    </message>
    <message>
        <location filename="foo.h" line="391"/>
        <source>MapAsia track file (.tr7)</source>
        <translation>Trazado MapAsia (.tr7)</translation>
    </message>
    <message>
        <location filename="foo.h" line="392"/>
        <source>Mapopolis.com Mapconverter CSV</source>
        <translation>Mapopolis.com Mapconverter CSV</translation>
    </message>
    <message>
        <location filename="foo.h" line="400"/>
        <source>MapTech Exchange Format</source>
        <translation>Formato de intercambio MapTech</translation>
    </message>
    <message>
        <location filename="foo.h" line="408"/>
        <source>Memory-Map Navigator overlay files (.mmo)</source>
        <translation>Capa de cobertura Memory-Map Navigator</translation>
    </message>
    <message>
        <location filename="foo.h" line="409"/>
        <source>Write items &apos;locked&apos; [default no]</source>
        <translation>Escribir elementos bloqueados [por defecto no]</translation>
    </message>
    <message>
        <location filename="foo.h" line="410"/>
        <source>Write items &apos;visible&apos; [default yes]</source>
        <translation>Escribir elementos &apos;visibles&apos; [por defecto si]</translation>
    </message>
    <message>
        <location filename="foo.h" line="411"/>
        <source>Write files with internal version [n]</source>
        <translation>Escribir ficheros con la versión del sistema [n]</translation>
    </message>
    <message>
        <location filename="foo.h" line="412"/>
        <source>Microsoft AutoRoute 2002 (pin/route reader)</source>
        <translation>Microsoft AutoRoute 2002 (lector de puntos y rutas)</translation>
    </message>
    <message>
        <location filename="foo.h" line="413"/>
        <source>Microsoft Streets and Trips (pin/route reader)</source>
        <translation>Microsoft Streets and Trips (lector de puntos y rutas)</translation>
    </message>
    <message>
        <location filename="foo.h" line="414"/>
        <source>Microsoft Streets and Trips 2002-2007</source>
        <translation>Microsoft Streets and Trips 2002-2007</translation>
    </message>
    <message>
        <location filename="foo.h" line="422"/>
        <source>Motorrad Routenplaner (Map&amp;Guide) .bcr files</source>
        <translation>Ficheros Motorrad Routenplaner (Map&amp;Guide) .bcr</translation>
    </message>
    <message>
        <location filename="foo.h" line="423"/>
        <location filename="foo.h" line="441"/>
        <source>Index of route to write (if more than one in source)</source>
        <translation>Indice de la ruta a escribir (si la fuente tiene más de uno)</translation>
    </message>
    <message>
        <location filename="foo.h" line="424"/>
        <source>New name for the route</source>
        <translation>Nuevo nombre de la ruta</translation>
    </message>
    <message>
        <location filename="foo.h" line="425"/>
        <source>Radius of our big earth (default 6371000 meters)</source>
        <translation>Radio del planeta tierra (por defecto 6371000 metros)</translation>
    </message>
    <message>
        <location filename="foo.h" line="427"/>
        <source>MS PocketStreets 2002 Pushpin</source>
        <translation>MS PocketStreets 2002 Pushpin</translation>
    </message>
    <message>
        <location filename="foo.h" line="428"/>
        <source>MTK Logger (iBlue 747,...) Binary File Format</source>
        <translation>Formato de fichero binario MTK Logger (iBlue 747,...)</translation>
    </message>
    <message>
        <location filename="foo.h" line="430"/>
        <source>MTK Logger (iBlue 747,Qstarz BT-1000,...) download</source>
        <translation>Descarga de MTK Logger (iBlue 747,...)</translation>
    </message>
    <message>
        <location filename="foo.h" line="434"/>
        <source>National Geographic Topo .tpg (waypoints)</source>
        <translation>National Geographic Topo .tpg (Puntos de interés)</translation>
    </message>
    <message>
        <location filename="foo.h" line="435"/>
        <source>Datum (default=NAD27)</source>
        <translatorcomment>esta opción es buena para América del Norte sólo</translatorcomment>
        <translation>Datum (default=NAD27, esta opción es buena para América del Norte sólo)</translation>
    </message>
    <message>
        <location filename="foo.h" line="436"/>
        <source>National Geographic Topo 2.x .tpo</source>
        <translation>National Geographic Topo 2.x .tpo</translation>
    </message>
    <message>
        <location filename="foo.h" line="437"/>
        <source>National Geographic Topo 3.x/4.x .tpo</source>
        <translation>National Geographic Topo 3.x/4.x .tpo</translation>
    </message>
    <message>
        <location filename="foo.h" line="438"/>
        <source>Navicache.com XML</source>
        <translation>Navicache.com XML</translation>
    </message>
    <message>
        <location filename="foo.h" line="439"/>
        <source>Suppress retired geocaches</source>
        <translation>Eliminar los geocaches recogidos</translation>
    </message>
    <message>
        <location filename="foo.h" line="440"/>
        <source>Navigon Mobile Navigator .rte files</source>
        <translation>Ficheros del Navigon Mobile Navigator .rte</translation>
    </message>
    <message>
        <location filename="foo.h" line="442"/>
        <source>Navigon Waypoints</source>
        <translation>Puntos de interés Navigon</translation>
    </message>
    <message>
        <location filename="foo.h" line="450"/>
        <source>NaviGPS GT-11/BGT-11 Download</source>
        <translation>Descarga de NaviGPS GT-11/BGT-11</translation>
    </message>
    <message>
        <location filename="foo.h" line="451"/>
        <source>Delete all track points</source>
        <translation>Borrrar todos los puntos del trazado</translation>
    </message>
    <message>
        <location filename="foo.h" line="452"/>
        <source>Delete all routes</source>
        <translation>Borrrar todas las rutas</translation>
    </message>
    <message>
        <location filename="foo.h" line="454"/>
        <source>Clear the datalog</source>
        <translation>Limpiar la memoria</translation>
    </message>
    <message>
        <location filename="foo.h" line="455"/>
        <source>Read from datalogger buffer</source>
        <translation>Leer de la memoria</translation>
    </message>
    <message>
        <location filename="foo.h" line="457"/>
        <source>NaviGPS GT-31/BGT-31 datalogger (.sbp)</source>
        <translation>Memoria del NaviGPS GT-31/BGT-31</translation>
    </message>
    <message>
        <location filename="foo.h" line="458"/>
        <source>NaviGPS GT-31/BGT-31 SiRF binary logfile (.sbn)</source>
        <translation>Fichero de almacenamiento binario del NaviGPS GT-31/BGT-31 SiRF</translation>
    </message>
    <message>
        <location filename="foo.h" line="459"/>
        <source>Naviguide binary route file (.twl)</source>
        <translation>Fichero binario de rutas Naviguide</translation>
    </message>
    <message>
        <location filename="foo.h" line="460"/>
        <source>&apos;wp&apos; - Create waypoint file , &apos;rte&apos; - Create route file</source>
        <translation>&apos;wp&apos; - Crear fichero de puntos de interés , &apos;rte&apos; - Crear fichero de rutas</translation>
    </message>
    <message>
        <location filename="foo.h" line="461"/>
        <source>&apos;n&apos; - Keep the existing wp name, &apos;y&apos; - rename waypoints</source>
        <translation>&apos;n&apos; - Conserva el nombre del punto de interés existente, &apos;y&apos; - cambia el nombre de los puntos de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="462"/>
        <source>Navitel binary track (.bin)</source>
        <translation>Trazado binario Navitel (.bin)</translation>
    </message>
    <message>
        <location filename="foo.h" line="463"/>
        <source>Navitrak DNA marker format</source>
        <translation>Fomato del marcador Navitrak DNA</translation>
    </message>
    <message>
        <location filename="foo.h" line="471"/>
        <source>NetStumbler Summary File (text)</source>
        <translation>Fichero resumen NetStumbler (texto)</translation>
    </message>
    <message>
        <location filename="foo.h" line="472"/>
        <source>Non-stealth encrypted icon name</source>
        <translatorcomment>Hay que encontrar una traducción mejor</translatorcomment>
        <translation>Nombre del icono encriptado pero no oculto</translation>
    </message>
    <message>
        <location filename="foo.h" line="473"/>
        <source>Non-stealth non-encrypted icon name</source>
        <translation>Nombre del icono desencriptado y no oculto</translation>
    </message>
    <message>
        <location filename="foo.h" line="474"/>
        <source>Stealth encrypted icon name</source>
        <translation>Nombre del icono oculto y encriptado</translation>
    </message>
    <message>
        <location filename="foo.h" line="475"/>
        <source>Stealth non-encrypted icon name</source>
        <translation>Nombre del icono oculto y no encriptado</translation>
    </message>
    <message>
        <location filename="foo.h" line="476"/>
        <location filename="foo.h" line="632"/>
        <source>Shortname is MAC address</source>
        <translation>El nombre corto es la MAC address</translation>
    </message>
    <message>
        <location filename="foo.h" line="477"/>
        <source>NIMA/GNIS Geographic Names File</source>
        <translation>Fichero de topónimos NIMA/GNIS</translation>
    </message>
    <message>
        <location filename="foo.h" line="485"/>
        <source>NMEA 0183 sentences</source>
        <translation>Frases NMEA 018</translation>
    </message>
    <message>
        <location filename="foo.h" line="486"/>
        <source>Max length of waypoint name to write</source>
        <translation>Longitud máxima del nombre del punto de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="487"/>
        <source>Read/write GPRMC sentences</source>
        <translation>Leer/escribir GPRMC frases</translation>
    </message>
    <message>
        <location filename="foo.h" line="488"/>
        <source>Read/write GPGGA sentences</source>
        <translation>Leer/escribir GPGGA frases</translation>
    </message>
    <message>
        <location filename="foo.h" line="489"/>
        <source>Read/write GPVTG sentences</source>
        <translation>Leer/escribir GPVTG frases</translation>
    </message>
    <message>
        <location filename="foo.h" line="490"/>
        <source>Read/write GPGSA sentences</source>
        <translation>Leer/escribir GPGSA frases</translation>
    </message>
    <message>
        <location filename="foo.h" line="493"/>
        <source>Decimal seconds to pause between groups of strings</source>
        <translation>Demora en décimas de segundo entre textos</translation>
    </message>
    <message>
        <location filename="foo.h" line="494"/>
        <source>Append realtime positioning data to the output file instead of truncating</source>
        <translation>Añadrir el la hora del poscionamiento al fichero de salida en lugar de truncarla</translation>
    </message>
    <message>
        <location filename="foo.h" line="495"/>
        <source>Speed in bits per second of serial port (baud=4800)</source>
        <translation>Velocidad en bits por segunod del puerto serie (4800 baudios)</translation>
    </message>
    <message>
        <location filename="foo.h" line="496"/>
        <source>Write tracks for Gisteq Phototracker</source>
        <translation>Escribir trazados para el Gisteq Phototracker</translation>
    </message>
    <message>
        <location filename="foo.h" line="497"/>
        <source>Nokia Landmark Exchange</source>
        <translation>Nokia Landmark Exchange</translation>
    </message>
    <message>
        <location filename="foo.h" line="498"/>
        <source>OpenStreetMap data files</source>
        <translation>Ficheros de datos de OpenStreetMap (gratuitos)</translation>
    </message>
    <message>
        <location filename="foo.h" line="499"/>
        <source>Write additional way tag key/value pairs</source>
        <translation>Escribir pares adiciones de clave/valor para la etiqueta de sentido</translation>
    </message>
    <message>
        <location filename="foo.h" line="500"/>
        <source>Write additional node tag key/value pairs</source>
        <translation>Escribir pares adiciones de clave/valor para la etiqueta de nodo</translation>
    </message>
    <message>
        <location filename="foo.h" line="501"/>
        <source>Use this value as custom created_by value</source>
        <translation>Usar este valor como valor personalizado</translation>
    </message>
    <message>
        <location filename="foo.h" line="502"/>
        <source>OziExplorer</source>
        <translation>OziExplorer</translation>
    </message>
    <message>
        <location filename="foo.h" line="503"/>
        <source>Write all tracks into one file</source>
        <translation>Escribir todos los trazados a un fichero único</translation>
    </message>
    <message>
        <location filename="foo.h" line="508"/>
        <source>Waypoint foreground color</source>
        <translation>Color del primer plano del punto de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="509"/>
        <source>Waypoint background color</source>
        <translation>Color del fondo del punto de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="510"/>
        <source>Proximity distance</source>
        <translation>Distancia de proximidad</translation>
    </message>
    <message>
        <location filename="foo.h" line="511"/>
        <source>Unit used in altitude values</source>
        <translation>Unidades usadas en los valores de altitud</translation>
    </message>
    <message>
        <location filename="foo.h" line="512"/>
        <source>Unit used in proximity values</source>
        <translation>Unidades usadas en los valores de proximidad</translation>
    </message>
    <message>
        <location filename="foo.h" line="513"/>
        <source>PalmDoc Output</source>
        <translation>Salida PalmDOC</translation>
    </message>
    <message>
        <location filename="foo.h" line="514"/>
        <source>No separator lines between waypoints</source>
        <translation>Sin saltos de línea entre los puntos de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="516"/>
        <source>Encrypt hints with ROT13</source>
        <translation>Emcriptar trucos usando ROT13</translation>
    </message>
    <message>
        <location filename="foo.h" line="518"/>
        <source>Include short name in bookmarks</source>
        <translation>Incluir el nombre corto en señalizadores</translation>
    </message>
    <message>
        <location filename="foo.h" line="519"/>
        <source>PathAway Database for Palm/OS</source>
        <translation>Base de Datos PathAway para Palm/OS</translation>
    </message>
    <message>
        <location filename="foo.h" line="520"/>
        <source>Read/Write date format (i.e. DDMMYYYY)</source>
        <translation>Leer/Escribir el formato de la fecha (por ejemplo DDMMAAAA)</translation>
    </message>
    <message>
        <location filename="foo.h" line="522"/>
        <source>Database vehicle icon name</source>
        <translation>Base de datos de las imágnes de vehículos</translation>
    </message>
    <message>
        <location filename="foo.h" line="525"/>
        <source>PocketFMS breadcrumbs</source>
        <translation>Picatostes de PocketFMS</translation>
    </message>
    <message>
        <location filename="foo.h" line="526"/>
        <source>PocketFMS flightplan (.xml)</source>
        <translation>Plan de vuelo de PocketFMS (.xml)</translation>
    </message>
    <message>
        <location filename="foo.h" line="527"/>
        <source>PocketFMS waypoints (.txt)</source>
        <translation>Punto de interés Pocket (.txt)</translation>
    </message>
    <message>
        <location filename="foo.h" line="528"/>
        <source>Quovadis</source>
        <translation>Quovadis</translation>
    </message>
    <message>
        <location filename="foo.h" line="530"/>
        <source>Raymarine Waypoint File (.rwf)</source>
        <translation>Fichero de puntos de interés Raymarine (.rwf)</translation>
    </message>
    <message>
        <location filename="foo.h" line="531"/>
        <source>Default location</source>
        <translation>Localización por defecto</translation>
    </message>
    <message>
        <location filename="foo.h" line="532"/>
        <source>Ricoh GPS Log File</source>
        <translation>Fichero de memoria de Ricoh GPS</translation>
    </message>
    <message>
        <location filename="foo.h" line="540"/>
        <source>See You flight analysis data</source>
        <translation>Revisar los datos del análisis de tu vuelo</translation>
    </message>
    <message>
        <location filename="foo.h" line="548"/>
        <source>Skymap / KMD150 ascii files</source>
        <translation>Ficheros Skymap / KMD150 ascii</translation>
    </message>
    <message>
        <location filename="foo.h" line="549"/>
        <source>SkyTraq Venus 5/6 GPS Data Logger Download</source>
        <translation>Descarga de datos SkyTraq Venus 5/6 GPS</translation>
    </message>
    <message>
        <location filename="foo.h" line="551"/>
        <source>Baud rate used to init device, 0=autodetect</source>
        <translation>Baudios usados para inicializar el dispositivo, autodetectar=0</translation>
    </message>
    <message>
        <location filename="foo.h" line="552"/>
        <source>Baud rate used for download</source>
        <translation>Baudios usados para la descarga</translation>
    </message>
    <message>
        <location filename="foo.h" line="553"/>
        <source>Number of sectors to read at once (Venus6 only)</source>
        <translation>Número de sectores que se leen cada vez (sólo Venus6)</translation>
    </message>
    <message>
        <location filename="foo.h" line="554"/>
        <source>Sportsim track files (part of zipped .ssz files)</source>
        <translation>Ficheros de trazado de Spotsim (partes de ficheros comprimidos .ssz)</translation>
    </message>
    <message>
        <location filename="foo.h" line="562"/>
        <source>Suunto Trek Manager (STM) .sdf files</source>
        <translation>Ficheros Suunto Trek Manager (STM) .sdf</translation>
    </message>
    <message>
        <location filename="foo.h" line="563"/>
        <source>Index of route (if more than one in source)</source>
        <translation>Indice de la ruta (si la fuente tiene más de uno)</translation>
    </message>
    <message>
        <location filename="foo.h" line="564"/>
        <source>Suunto Trek Manager (STM) WaypointPlus files</source>
        <translation>Ficheros Suunto Trek Manager (STM) WaypointPlus</translation>
    </message>
    <message>
        <location filename="foo.h" line="566"/>
        <source>Swiss Map 25/50/100 (.xol)</source>
        <translation>Swiss Map 25/50/100 (.xol)</translation>
    </message>
    <message>
        <location filename="foo.h" line="567"/>
        <source>Tab delimited fields useful for OpenOffice, Ploticus etc.</source>
        <translation>Campos delimitados por tabuladores, útila para OpenOffice, Ploticus etc.</translation>
    </message>
    <message>
        <location filename="foo.h" line="575"/>
        <source>Textual Output</source>
        <translation>Salida literal</translation>
    </message>
    <message>
        <location filename="foo.h" line="576"/>
        <source>Suppress separator lines between waypoints</source>
        <translation>Suprimir saltos de línea entre los puntos de interés</translation>
    </message>
    <message>
        <location filename="foo.h" line="581"/>
        <source>Write each waypoint in a separate file</source>
        <translation>escribir cada punto de interés en un fichero separado</translation>
    </message>
    <message>
        <location filename="foo.h" line="582"/>
        <source>TomTom Itineraries (.itn)</source>
        <translation>TomTom Itineraries (.itn)</translation>
    </message>
    <message>
        <location filename="foo.h" line="590"/>
        <source>TomTom POI file (.asc)</source>
        <translation>TomTom POI file (.asc)</translation>
    </message>
    <message>
        <location filename="foo.h" line="598"/>
        <source>TomTom POI file (.ov2)</source>
        <translation>TomTom POI file (.ov2)</translation>
    </message>
    <message>
        <location filename="foo.h" line="599"/>
        <source>TopoMapPro Places File</source>
        <translation>Fichero de TopoMapPro Places</translation>
    </message>
    <message>
        <location filename="foo.h" line="600"/>
        <source>TrackLogs digital mapping (.trl)</source>
        <translation>Mapa digital TrackLogs (.trl)</translation>
    </message>
    <message>
        <location filename="foo.h" line="601"/>
        <source>Index of track (if more than one in source)</source>
        <translation>Indice del trazado (si la fuente tiene más de uno)</translation>
    </message>
    <message>
        <location filename="foo.h" line="602"/>
        <source>U.S. Census Bureau Tiger Mapping Service</source>
        <translation>Servicio de mapas Tgier del U.S. Census Bureau</translation>
    </message>
    <message>
        <location filename="foo.h" line="603"/>
        <source>Suppress labels on generated pins</source>
        <translation>Suprimir etiquetas en los puntos creados</translation>
    </message>
    <message>
        <location filename="foo.h" line="604"/>
        <source>Generate file with lat/lon for centering map</source>
        <translation>Crear fichero con lat/lon para centrar el mapa</translation>
    </message>
    <message>
        <location filename="foo.h" line="605"/>
        <source>Margin for map.  Degrees or percentage</source>
        <translation>Margen del mapa. Grados o porcentaje</translation>
    </message>
    <message>
        <location filename="foo.h" line="606"/>
        <source>Max shortname length when used with -s</source>
        <translation>Max nombre corto cuando se usa -s</translation>
    </message>
    <message>
        <location filename="foo.h" line="607"/>
        <source>Days after which points are considered old</source>
        <translation>Número de días a partir del cual los puntos se consideran antiguos</translation>
    </message>
    <message>
        <location filename="foo.h" line="608"/>
        <source>Marker type for old points</source>
        <translation>Tipo de marca para los puntos antiguos </translation>
    </message>
    <message>
        <location filename="foo.h" line="609"/>
        <source>Marker type for new points</source>
        <translation>Tipo de marca para los puntos nuevos </translation>
    </message>
    <message>
        <location filename="foo.h" line="610"/>
        <source>Suppress whitespace in generated shortnames</source>
        <translation>Suprimir espacios en nombres cortos generados</translation>
    </message>
    <message>
        <location filename="foo.h" line="611"/>
        <source>Marker type for unfound points</source>
        <translation>Tipo de marca para los puntos no encontrados</translation>
    </message>
    <message>
        <location filename="foo.h" line="612"/>
        <source>Width in pixels of map</source>
        <translation>Anchura del mapa (píxeles)</translation>
    </message>
    <message>
        <location filename="foo.h" line="613"/>
        <source>Height in pixels of map</source>
        <translation>Altura del mapa (píxeles)</translation>
    </message>
    <message>
        <location filename="foo.h" line="614"/>
        <source>The icon description is already the marker</source>
        <translation>La descripción ya es la marca</translation>
    </message>
    <message>
        <location filename="foo.h" line="615"/>
        <source>Universal csv with field structure in first line</source>
        <translation>Formato csv universal con la estructura de campos en la primera línea</translation>
    </message>
    <message>
        <location filename="foo.h" line="619"/>
        <source>Write name(s) of format(s) from input session(s)</source>
        <translation>Escribir los de los formatos de entrada en cada sesión</translation>
    </message>
    <message>
        <location filename="foo.h" line="620"/>
        <source>Write filename(s) from input session(s)</source>
        <translation>Escribir el nombre de los ficheros de entrada en cada sesión</translation>
    </message>
    <message>
        <location filename="foo.h" line="621"/>
        <source>Vcard Output (for iPod)</source>
        <translation>Salida Vcard (para iPod)</translation>
    </message>
    <message>
        <location filename="foo.h" line="623"/>
        <source>VidaOne GPS for Pocket PC (.gpb)</source>
        <translation>GPS VidaOne para Pocket PC (.gpb)</translation>
    </message>
    <message>
        <location filename="foo.h" line="624"/>
        <source>Version of VidaOne file to read or write (1 or 2)</source>
        <translation>Versión del fichero VidaOne para leer o escribir (1 ó 2)</translation>
    </message>
    <message>
        <location filename="foo.h" line="625"/>
        <source>Vito Navigator II tracks</source>
        <translation>Trazados Vito Navigator II</translation>
    </message>
    <message>
        <location filename="foo.h" line="626"/>
        <source>Vito SmartMap tracks (.vtt)</source>
        <translation>Trazados Vito SmartMap (.vtt)</translation>
    </message>
    <message>
        <location filename="foo.h" line="627"/>
        <source>WiFiFoFum 2.0 for PocketPC XML</source>
        <translation>WiFiFoFum 2.0 para PocketPC XML</translation>
    </message>
    <message>
        <location filename="foo.h" line="628"/>
        <source>Infrastructure closed icon name</source>
        <translation>Nombre del icono de infraestructura cerrada</translation>
    </message>
    <message>
        <location filename="foo.h" line="629"/>
        <source>Infrastructure open icon name</source>
        <translation>Nombre del icono de infraestructura abierta</translation>
    </message>
    <message>
        <location filename="foo.h" line="630"/>
        <source>Ad-hoc closed icon name</source>
        <translation>Nombre del icono cerrado ad-hoc</translation>
    </message>
    <message>
        <location filename="foo.h" line="631"/>
        <source>Ad-hoc open icon name</source>
        <translation>Nombre del icono abierto ad-hoc</translation>
    </message>
    <message>
        <location filename="foo.h" line="633"/>
        <source>Wintec WBT-100/200 Binary File Format</source>
        <translation>Formato de fichero binario Wintec WBT-100/200</translation>
    </message>
    <message>
        <location filename="foo.h" line="634"/>
        <source>Wintec WBT-100/200 GPS Download</source>
        <translation>Descarga de Wintec WBT-100/200 GPS</translation>
    </message>
    <message>
        <location filename="foo.h" line="636"/>
        <source>Wintec WBT-201/G-Rays 2 Binary File Format</source>
        <translation>Formato de fichero binario Wintec WBT-201/G-Rays 2</translation>
    </message>
    <message>
        <location filename="foo.h" line="637"/>
        <source>XAiOX iTrackU Logger</source>
        <translation>Registors del XAiOX iTrackU</translation>
    </message>
    <message>
        <location filename="foo.h" line="638"/>
        <location filename="foo.h" line="641"/>
        <source>Appends the input to a backup file</source>
        <translation>Añadir la entrada a una copia de seguridad</translation>
    </message>
    <message>
        <location filename="foo.h" line="639"/>
        <location filename="foo.h" line="642"/>
        <source>Only waypoints that are not the backup file</source>
        <translation>Sólo los puntos que no están en la copia de seguridad</translation>
    </message>
    <message>
        <location filename="foo.h" line="640"/>
        <source>XAiOX iTrackU Logger Binary File Format</source>
        <translation>Formato de fichero binario XAiOX iTrackU Logger</translation>
    </message>
    <message>
        <location filename="foo.h" line="643"/>
        <source>Yahoo Geocode API data</source>
        <translation>Datos de geocodificación Yahoo API</translation>
    </message>
    <message>
        <location filename="foo.h" line="644"/>
        <source>String to separate concatenated address fields (default=&quot;, &quot;)</source>
        <translation>Texto para separar campos de dirección (&quot;,&quot; por defecto)</translation>
    </message>
</context>
</TS>
